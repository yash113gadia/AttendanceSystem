#!/bin/bash
java -jar AttendEase.jar
